import React from "react"

const App = () => <h1 class="react">
    I am React Application for Micro frontend</h1>

export default App