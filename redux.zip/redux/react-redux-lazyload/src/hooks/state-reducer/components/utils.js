export const longText = `Lorem ipsum dolor sit amet, et noster prodesset moderatius nam. Omnium postulant qui ea, usu veniam vivendo tibique ei. Ei vim elit debet tibique. Ea utroque graecis omittantur mea, vocibus singulis id pri, nec no audire definiebas.

Vim harum maiestatis scriptorem ad, vix mundi dicant te. Dolorem minimum torquatos est cu, equidem veritus usu no, ut his purto dicit populo. Omnes fabellas no qui, utamur detraxit id ius. Et nisl posidonium pri. In laudem possim eum, quo ridens periculis neglegentur id.

Ne eos quas deleniti, ut vis tantas laudem aliquip. Duo virtute vulputate vituperata ea, facilisi efficiendi ea pri. Eu mea accumsan mentitum probatus, quando regione sed ut. Propriae persecuti disputationi no vim, his assueverit scripserit necessitatibus eu. Assentior sententiae ne duo, ei vix inani facilisi sadipscing. Paulo facete nec ad.

Aliquip definitiones vix et. Usu esse percipitur quaerendum ut, solet aliquid antiopam te his. Quaeque voluptaria vituperatoribus an eos, in nostrum convenire mea. Ei viris epicuri eam, sit ut dolorum delectus ocurreret. Et sit diam nostro, pro ei volutpat quaerendum neglegentur, ea his dicam postulant. Pro id case aliquando, accusam fabellas nec et.

Enim utroque ei vel, his ei sint eirmod veritus. Ut eum error aliquip assentior. Sea in bonorum recteque, an pro partem volutpat. Brute debet pericula et usu. Appellantur adversarium mel in.`
