export const USER = {
  name: 'Murthy',
  totalAmount: 25000
}
