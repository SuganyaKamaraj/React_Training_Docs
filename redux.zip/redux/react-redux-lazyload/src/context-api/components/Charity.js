import React from 'react'

const Charity = () => {
  return <p className='App__giveaway'>Give away all your cash to charity</p>
}

export default Charity
