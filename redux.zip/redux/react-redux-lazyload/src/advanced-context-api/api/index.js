export const USER = {
  name: 'Sriram',
  totalAmount: 50000
}
