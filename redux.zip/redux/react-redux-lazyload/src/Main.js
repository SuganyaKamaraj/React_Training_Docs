
import React from 'react';

//import Root from './context-api /Root'
//import Root from './lazy-loading/Root'
//import CompoundApp from './hooks/compound-component/CompoundApp'
//import App from './hooks/control-props/App'
//import App from './hooks/prop-collection/App'
//import App from './hooks/state-reducer/App'

import LifecycleApp from './comp-life-cycle/basics/LifeCycleApp'
function Main() {
  return (
          <LifecycleApp />          
  )
}

export default Main;
