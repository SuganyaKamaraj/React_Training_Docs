export const GET_USERS = 'forkspwanexample/GET_USERS';
export const GET_USERS_SUCCESS = 'forkspwanexample/GET_USERS_SUCCESS';

export const GET_COMMENTS = 'forkspwanexample/GET_COMMENTS';
export const GET_COMMENTS_SUCCESS = 'forkspwanexample/GET_COMMENTS_SUCCESS';

export const ERROR = 'forkspwanexample/ERROR';

export const RUN_FORK = 'RUN_FORK_EXAMPLE';
export const RUN_SPAWN = 'RUN_SPAWN_EXAMPLE';