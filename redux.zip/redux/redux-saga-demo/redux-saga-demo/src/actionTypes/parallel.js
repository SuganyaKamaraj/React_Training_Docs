export const GET_USERS = 'parallel/GET_USERS';
export const GET_USERS_SUCCESS = 'parallel/GET_USERS_SUCCESS';

export const GET_CITIES = 'parallel/GET_CITIES';
export const GET_CITIES_SUCCESS = 'parallel/GET_CITIES_SUCCESS';

export const GET_DATA = 'parallel/GET_DATA';
export const ERROR = 'parallel/ERROR';
