export const GREET = 'GREET';
export const ADD_INPUTS ='ADD_INPUTS'
export const SUBTRACT_INPUTS = 'SUBTRACT_INPUTS'

