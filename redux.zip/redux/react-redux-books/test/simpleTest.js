import expect from 'expect'

describe('Mocha', () => {
  it('should work', () => {
    expect(1).toBe(1)
  })
})
