# React Redux Banking

React redux banking is an sample front end with react, redux, babel, hot reloading, testing, linting, semantic UI based on react-slingshot.

To get started, clone the repo, run npm install then npm start to run locally, or npm run build to compile distribution version.

Try the demo at: http://react-redux-bank.s3-website-us-east-1.amazonaws.com/
