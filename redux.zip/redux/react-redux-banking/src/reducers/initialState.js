export default {
  balance: 0,
  withdrawals: [],
  deposits: []
};
