/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetVisibilityFilter
// ====================================================

export interface GetVisibilityFilter_visibilityFilter {
  __typename: "VisibilityFilter";
  id: string;
  displayName: string;
}

export interface GetVisibilityFilter {
  visibilityFilter: GetVisibilityFilter_visibilityFilter;
}
