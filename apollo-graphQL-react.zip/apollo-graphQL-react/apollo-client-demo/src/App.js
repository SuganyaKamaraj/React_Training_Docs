import Missions from './components/Missions';

function App() {
  return <Missions/>;
}

export default App;
