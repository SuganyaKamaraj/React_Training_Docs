export { StarWarsSchema as default } from './swapiSchema'
